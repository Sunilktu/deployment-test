from flask import Flask, jsonify
from Adani_AnnotationTool import freehand_annotation as fh
import json

app = Flask(__name__)

@app.route('/')
def index():
    f = open("input_annotation.json")
    data = json.load(f)
    f.close()
    source_folder="input_image"
    destination_folder="output_image"
    thickness =2
    image_height = 512
    image_width = 512

    #source_folder = data["source_folder"]
    #destination_folder = data["destination_folder"]
    #thickness = data["thickness"]
    #image_height = data["image_height"]
    #image_width = data["image_width"]

    fh.im_anotate(source_folder, destination_folder, thickness, image_height, image_width)

    return jsonify({"message": "Annotation completed successfully."})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000,debug=True)  # Run the Flask app on port 5000
