import logging
from Adani_AnnotationTool import freehand_annotation as fh
import cv2
import os
import json
import numpy as np
#print("Current Directory:", os.getcwd())

try:
    
    # Your existing code here
    # %%
    f=open("../input_annotation.json") 
    data = json.load(f)
    f.close()
    #print(fh.global_variable)
    #global drawing, last_x, last_y, annotation_coords

    # Source folder containing images for annotation
    source_folder = data["source_folder"]
    destination_folder = data["destination_folder"]
    thickness=data["thickness"]
    image_height=data["image_height"]
    image_width=data["image_width"]


    fh.im_anotate(source_folder,destination_folder,thickness,image_height,image_width)    




# %%

# %%




except Exception as e:
    logging.exception("An error occurred: %s", str(e))
    input("Press Enter to exit...")

